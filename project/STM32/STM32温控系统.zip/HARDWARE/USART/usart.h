#ifndef _USART_H
#define _USART_H

#include "sys.h"
#include "stdio.h"


extern unsigned char RecFlag;
void UART_Init(unsigned int bound);

//�ṹ��

typedef struct 
{
	unsigned char Head;
	unsigned char Type;
	unsigned char Length;
	unsigned char Data_High;
	unsigned char Date_Low;
	unsigned char JiaoYan;
	unsigned char Tall;
	
}Uart_Data;



typedef union
{
	unsigned char UartRec_Data[7];
	Uart_Data UartRec_Inf;
	
}Uart_Inf;

extern Uart_Inf Uart1_inf;

#endif


