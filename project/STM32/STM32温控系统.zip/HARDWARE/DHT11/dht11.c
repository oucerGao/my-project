#include "dht11.h"
#include "delay.h"

DHT11_Data_TypeDef DHT11_Data;
void DHT11_Mode_OUT_PP(void) //����PA2 ���ģʽ
{
	 GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 

  GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	
}	

void DHT11_Mode_IN_NP(void)//����PA2Ϊ����ģʽ
{
	 GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 

  GPIO_Init(GPIOA,&GPIO_InitStructure);
}

unsigned char DHT11_ReadByte(void)
{
	unsigned i = 0;
	unsigned temp = 0;
	for(i=0; i < 8 ;i++)
	{
		while(DHT11_IN == 0);
		delay_us(40);
		if(DHT11_IN == 1)
		{
				while(DHT11_IN == 1);
			
			  temp |= (unsigned char )(0x01 << (7-i));
		}
		else
		{
			temp &= (unsigned char )~(0x01 << (7-i));
		}	
	}
	return temp;
}
	


unsigned char DHT11_ReadData(DHT11_Data_TypeDef *DHT11_AData)
{
	DHT11_Mode_OUT_PP();
	DHT11_OUT_0;
	delay_ms(20);
	DHT11_OUT_1;
	delay_us(30);
	DHT11_Mode_IN_NP();
	if(DHT11_IN == 0)
	{
		while(DHT11_IN == 0);
				
		while(DHT11_IN == 1);
		DHT11_AData->humi_int = DHT11_ReadByte();
		DHT11_AData->humi_deci = DHT11_ReadByte();
		DHT11_AData->temp_int  = DHT11_ReadByte();
		DHT11_AData->temp_deci = DHT11_ReadByte();
		DHT11_AData->check_sum =  DHT11_ReadByte();
		
	  DHT11_Mode_OUT_PP();
		DHT11_OUT_1;
		
		//У��
		if(DHT11_AData->check_sum == (DHT11_AData->humi_int + DHT11_AData->humi_deci +DHT11_AData->temp_int +DHT11_AData->temp_deci))
		{
		 return 1;
		}
		else
		{
		  return 0;
		
	  }
	}	
	else
	{
		return 0;
	}


}

