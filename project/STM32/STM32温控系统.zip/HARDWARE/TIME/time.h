#ifndef __TIME_H
#define __TIME_H

#include "sys.h"


void TIM3_Init(unsigned int arr,unsigned int psc);

#endif


