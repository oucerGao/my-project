#include "sys.h"	
#include "delay.h"	
#include "led.h" 
#include "beep.h"
#include "time.h"
#include "usart.h"
#include "oled.h"
#include "dht11.h"
#include "bmp.h"
 int main(void)
 {
	 unsigned char Result_Flag = 0;
		delay_init();	    	 //��ʱ������ʼ��	  
    BEEP_Init();
		//TIM3_Init(19,7199);         //4999 7299 500ms 0.5s	 
	  OLED_Init();
	  OLED_ColorTurn(0);
	  OLED_DisplayTurn(0);
		OLED_Refresh();
		BEEP=0;
		while(1)
		{
			OLED_Refresh();
			Result_Flag = DHT11_ReadData(&DHT11_Data);
			if(Result_Flag ==1)
			{	

				int a=DHT11_Data.temp_int*10;
				int a1=a/100;
				int a2=(a-a1*100)/10;
				int a3=DHT11_Data.temp_deci;
				OLED_ShowChinese(10,0,12,16);//��
				OLED_ShowChinese(25,0,13,16);//ǰ
				OLED_ShowChinese(40,0,14,16);//��
				OLED_ShowChinese(55,0,11,16);//��
				OLED_ShowChinese(70,0,16,16);//��
				OLED_ShowChinese(50,15,a1,16);//ʮλ
				OLED_ShowChinese(65,15,10,16);//ʮ
				OLED_ShowChinese(80,15,a2,16);//��λ
				OLED_ShowChinese(95,15,11,16);//��
				OLED_ShowChinese(110,15,a3,16);
				OLED_ShowChinese(10,30,17,16);//״
				OLED_ShowChinese(25,30,18,16);//̬
				OLED_ShowChinese(40,30,16,16);//��
			
				if(a>=370&&a3>3)
				{
				OLED_ShowChinese(70,45,20,16);//��
				OLED_ShowChinese(85,45,21,16);//��
				BEEP=1;
				}
				else	{
				OLED_ShowChinese(55,45,19,16);//δ
				OLED_ShowChinese(70,45,20,16);//��
				OLED_ShowChinese(85,45,21,16);//��
				BEEP=0;
				}
			}
    }
}