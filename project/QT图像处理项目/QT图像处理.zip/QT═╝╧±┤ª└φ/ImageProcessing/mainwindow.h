#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QToolBar>
#include <QMenuBar>
#include <QImage>
#include <QLabel>
#include <QAction>
#include <QString>
#include <QFileDialog>
#include <QPixmap>
#include <QVector>
#include <QMessageBox>
#include <QFormLayout>
#include <QSpinBox>
#include <QDialogButtonBox>
#include <QInputDialog>
#include "image.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void on_save_triggered();//保存图像
    void on_save_as_triggered();//另存为
    void on_back_triggered();//后退一步
    void on_next_triggered();//前进一步
    void showImg();//显示图片
    void checkCopies();//检查前进或后退操作是否结束，删除index到size()-1的图片副本
    void on_close_triggered();//关闭当前图片
    void on_actiongray_scale_triggered();//转为灰度图
    void on_actionresize_triggered();//修改尺寸
    void on_actionaverage_triggered();//求均值
    void on_actionvariance_triggered();//求方差
    void on_actionfilpUpanDown_triggered();//上下翻转
    void on_actionfilpLeftAndRight_triggered();//左右翻转
    void on_actionopen_triggered();//打开图片
    void on_actionlaplacian_triggered();//laplacian锐化
    void on_actionsobel_triggered();//边缘检测
    void on_actionhigh_passFilter_triggered();//高通滤波
    void on_actiongaussianblur_triggered();//高斯模糊
    void on_actionbinarization_triggered();//二值化
    void on_actioncontourdetection_triggered();//轮廓提取

private:
    Ui::MainWindow *ui;
    QString fileName;
    QVector<Image> copies;
    Image * img;
    int index = 0;
    QWidget * res = nullptr;

};
#endif // MAINWINDOW_H
