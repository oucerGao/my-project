#ifndef IMAGE_H
#define IMAGE_H

#include <windows.h>
#include <QString>
#include <QFile>
#include <QDataStream>
#include <cmath>
class Image
{
public:
    Image();
    Image(const Image& img);
    void ReadBMP(const char* ImageName); //从硬盘文件中读入图像数据;
    void WriteBMP(const char* filename); //将图像数据保存为图像文件;
    unsigned char* getPixel(unsigned char * pixData, int row, int col) const;
    unsigned char* getData()const;
    int getWidth() const;
    int getHeight() const;
    int getPrimaryWidth() const;
    double * average();
    double * variance();
    void resize(int newHeight, int newWidth);//缩放
    void FilpUpAndDown();//上下翻转
    void FilpLeftAndRight();//左右翻转
    void swapPixel(int x1, int y1, int x2, int y2);//交换两个位置的像素
    void LaplacainSharpening();//Laplacain
    void High_passFilter();//高通滤波
    void SobelSharpening();//边缘检测
    void Gaussian_Blur(double sigma);//高斯模糊
    void ToGray();//转为灰度图，不改变深度
    void Binarization();//二值化
    void Contour_Detection();//轮廓提取
private:
    unsigned char * data = nullptr;
    int height;
    int width;//补0后的宽
    int primaryWidth;//补0前一行像素数
    BITMAPFILEHEADER * filehead = nullptr;
    BITMAPINFOHEADER * infohead = nullptr;
};

#endif // IMAGE_H
